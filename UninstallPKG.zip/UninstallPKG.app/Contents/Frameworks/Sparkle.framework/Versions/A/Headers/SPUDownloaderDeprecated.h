//
//  SPUDownloaderDeprecated.h
//  Sparkle
//
//  Created by Deadpikle on 12/20/17.
//  Copyright © 2017 Sparkle Project. All rights reserved.
//

#import "SPUDownloader.h"

@interface SPUDownloaderDeprecated : SPUDownloader <SPUDownloaderProtocol>

@end
