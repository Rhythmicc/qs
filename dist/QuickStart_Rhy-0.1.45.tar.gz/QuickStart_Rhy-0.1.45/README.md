## Docs
|Location|Url|
|:---:|:---:|
|China|[Docs](https://rhythmlian.cn/2020/02/14/QuickStart-Rhy/)|
|Other|[Docs](https://www.rhythmlian.cn/2020/02/14/QuickStart-Rhy/)|
