<h1 style="text-align: center"> QuickStart_Rhy </h1>

## Install
```shell
pip3 install quickstart-rhy
```
**Env: ^Python 3.7**

**Font: [Cascadia Code](https://github.com/microsoft/cascadia-code/releases/download/v2111.01/CascadiaCode-2111.01.zip)**

## Docs
| |Url|
|:---:|:---:|
|1|https://rhythmlian.cn/2020/02/14/QuickStart-Rhy/      |
|2|https://rhythmicc.github.io/2020/02/14/QuickStart-Rhy/|

## Tab Complete (zsh only)
```shell
mv _qs /path/in/$fpath/
```
