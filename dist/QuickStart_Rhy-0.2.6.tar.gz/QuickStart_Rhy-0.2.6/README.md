## Docs
|Location|Url|
|:---:|:---:|
|China|[Docs](https://rhythmlian.cn/2020/02/14/QuickStart-Rhy/)|
|Other|[Docs](https://rhythmicc.github.io/2020/02/14/QuickStart-Rhy/)|
