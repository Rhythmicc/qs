- [ QuickStart_Rhy ](#quickstart_rhy)
  - [Install](#install)
  - [Docs](#docs)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

<h1 style="text-align: center"> QuickStart_Rhy </h1>

## Install
```shell
pip3 install quickstart-rhy
```
**Env: ^Python 3.7**

## Docs
| |Url|
|:---:|:---:|
|1|https://rhythmlian.cn/2020/02/14/QuickStart-Rhy/      |
|2|https://rhythmicc.github.io/2020/02/14/QuickStart-Rhy/|

